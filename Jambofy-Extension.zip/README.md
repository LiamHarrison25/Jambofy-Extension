# Jambofy Chrome Extension



<p align="center">
  <img src="https://lh3.googleusercontent.com/Nw4bhfjeIqi9gXZXH1Jv9Qr7_oQb5ziM1r_yPh-PTZawSAan3M77cxazYB0CmR-nhlZIrAfrXB7JqXvcWJ4JkZK4=w640-h400-e365-rj-sc0x00ffffff" alt="Jambofy Image" width = "800" height="500" style="align-items=center; justify-content=center;" />
</p>

Programmed by [Liam](https://www.youtube.com/@puffbee21) 

<p align="center">
    <img src="https://yt3.googleusercontent.com/ytc/AIf8zZSPtXEqp1ONDHDfaWUNmbX5DRiMfxpFFcqgtIB98A=s176-c-k-c0x00ffffff-no-rj" alt="Liam Youtube" width="100" height="100" style="align-items=center; justify-content=center;" />
</p>
<br />

Photoshopping and videos by [Peam](https://www.youtube.com/@Sopeamy)
<p align="center">
    <img src="https://yt3.googleusercontent.com/wUxXQk9a2RBEF4nLCk-3Mm1MOeXV3TRMc4T1ib7zPbJW15qRlJb-qc89WncPgEy8hMd0una5rEw=s176-c-k-c0x00ffffff-no-rj" alt="Peam Youtube" width="100" height="100" style="align-items=center; justify-content=center;" />
</p>
<br />

##

This extension was originally made as a submission for Jshlatt's Shark Tank Pitch Stream in late 2023. 
<br />
Link to video:
https://youtu.be/H5iqrUr4uYk?si=b0lR5J_ZlHQQlp2p 
<br />
Link to extension store page:
https://chromewebstore.google.com/detail/jambofy/ecbedadooalalcgolmfgpnmphhccegei 
<br />
The idea for this extension was inspired by the MrBeastify extension:
<br />
https://chromewebstore.google.com/detail/youtube-mrbeastify/dbmaeobgdodeimjdjnkipbfhgeldnmeb
